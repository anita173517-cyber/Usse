package com.harindra.iptvpro.vod

import androidx.media3.common.PlaybackException
import androidx.media3.datasource.HttpDataSource
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

/**
 * Dedicated VOD Playback Error Handler & Bounded Retry Engine.
 *
 * - Strictly independent from Live TV's channel reconnect / fast-zapping logic.
 * - Never triggers infinite retry loops (hard cap: max 3 transient retries, 0 for fatal errors).
 * - Never exposes credentials or sensitive URLs in error messages.
 */
class VodPlaybackErrorHandler(
    private val maxTransientRetries: Int = 3
) {
    private var retryCount: Int = 0

    fun reset() {
        retryCount = 0
    }

    fun currentRetryCount(): Int = retryCount

    fun classifyHttpStatus(httpCode: Int): VodErrorInfo {
        return when (httpCode) {
            401, 403 -> VodErrorInfo(
                category = VodErrorCategory.AUTH_EXPIRED,
                httpCode = httpCode,
                title = "Authentication Failed (HTTP $httpCode)",
                message = "Your Xtream account session expired or this VOD item is not authorized by your provider.",
                canRetry = false,
                retryCount = retryCount,
                maxRetries = 0
            )
            404, 410 -> VodErrorInfo(
                category = VodErrorCategory.NOT_FOUND,
                httpCode = httpCode,
                title = "Media Not Found (HTTP $httpCode)",
                message = "This movie or episode is no longer available on the provider server.",
                canRetry = false,
                retryCount = retryCount,
                maxRetries = 0
            )
            429 -> VodErrorInfo(
                category = VodErrorCategory.RATE_LIMITED,
                httpCode = httpCode,
                title = "Server Busy (HTTP 429)",
                message = "Provider rate limit reached. Wait a moment and retry playback.",
                canRetry = retryCount < maxTransientRetries,
                retryCount = retryCount,
                maxRetries = maxTransientRetries
            )
            in 500..599 -> VodErrorInfo(
                category = VodErrorCategory.SERVER_ERROR,
                httpCode = httpCode,
                title = "Provider Server Error (HTTP $httpCode)",
                message = "The streaming server is temporarily unavailable. You can retry safely.",
                canRetry = retryCount < maxTransientRetries,
                retryCount = retryCount,
                maxRetries = maxTransientRetries
            )
            else -> VodErrorInfo(
                category = VodErrorCategory.NETWORK_INTERRUPTED,
                httpCode = httpCode,
                title = "Stream Connection Error (HTTP $httpCode)",
                message = "Could not load the media stream from the server.",
                canRetry = retryCount < maxTransientRetries,
                retryCount = retryCount,
                maxRetries = maxTransientRetries
            )
        }
    }

    fun classifyException(error: PlaybackException): VodErrorInfo {
        val cause = error.cause
        if (cause is HttpDataSource.InvalidResponseCodeException) {
            return classifyHttpStatus(cause.responseCode)
        }
        val errCode = error.errorCode
        return when {
            errCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED ||
                errCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ||
                cause is SocketTimeoutException ||
                cause is UnknownHostException -> VodErrorInfo(
                category = VodErrorCategory.NETWORK_INTERRUPTED,
                title = "Network Interrupted",
                message = "Connection timed out or network dropped. Check Wi-Fi/Ethernet and retry.",
                canRetry = retryCount < maxTransientRetries,
                retryCount = retryCount,
                maxRetries = maxTransientRetries
            )
            errCode == PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED ||
                errCode == PlaybackException.ERROR_CODE_PARSING_MANIFEST_UNSUPPORTED -> VodErrorInfo(
                category = VodErrorCategory.MANIFEST_ERROR,
                title = "HLS / DASH Manifest Error",
                message = "The provider stream manifest could not be parsed cleanly.",
                canRetry = retryCount < maxTransientRetries,
                retryCount = retryCount,
                maxRetries = maxTransientRetries
            )
            errCode == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED ||
                errCode == PlaybackException.ERROR_CODE_DECODING_FAILED -> VodErrorInfo(
                category = VodErrorCategory.DECODER_FAILURE,
                title = "Video Decoder Error",
                message = "The TV hardware decoder encountered an error. Retrying with decoder fallback.",
                canRetry = retryCount < 1,
                retryCount = retryCount,
                maxRetries = 1
            )
            errCode == PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED ||
                errCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED -> VodErrorInfo(
                category = VodErrorCategory.UNSUPPORTED_CODEC,
                title = "Unsupported Media Format",
                message = "This video or audio codec is not supported by your TV hardware.",
                canRetry = false,
                retryCount = retryCount,
                maxRetries = 0
            )
            errCode == PlaybackException.ERROR_CODE_AUDIO_TRACK_INIT_FAILED ||
                errCode == PlaybackException.ERROR_CODE_AUDIO_TRACK_WRITE_FAILED -> VodErrorInfo(
                category = VodErrorCategory.AUDIO_TRACK_FAILURE,
                title = "Audio Track Error",
                message = "Audio output failed for the selected track. Try switching audio track.",
                canRetry = retryCount < 1,
                retryCount = retryCount,
                maxRetries = 1
            )
            errCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED ||
                cause is IOException -> VodErrorInfo(
                category = VodErrorCategory.CORRUPT_MEDIA,
                title = "Corrupt or Unreadable Stream",
                message = "The media file could not be read cleanly from the server.",
                canRetry = retryCount < maxTransientRetries,
                retryCount = retryCount,
                maxRetries = maxTransientRetries
            )
            else -> VodErrorInfo(
                category = VodErrorCategory.UNKNOWN,
                title = "VOD Playback Error",
                message = "Unable to play this title right now. Press Retry or go back to details.",
                canRetry = retryCount < maxTransientRetries,
                retryCount = retryCount,
                maxRetries = maxTransientRetries
            )
        }
    }

    fun classifyInvalidUrl(): VodErrorInfo {
        return VodErrorInfo(
            category = VodErrorCategory.INVALID_URL,
            title = "Invalid Media URL",
            message = "This title does not have a valid playable stream address.",
            canRetry = false,
            retryCount = 0,
            maxRetries = 0
        )
    }

    /**
     * Attempts to consume one retry budget slot for a retryable error.
     * Returns backoff delay in ms, or null if retry is disallowed / exhausted.
     */
    fun nextRetryDelayMs(errorInfo: VodErrorInfo): Long? {
        if (!errorInfo.canRetry || !errorInfo.category.isRetryable) return null
        if (retryCount >= errorInfo.maxRetries) return null
        retryCount++
        return when (retryCount) {
            1 -> 1_200L
            2 -> 2_500L
            else -> 4_000L
        }
    }
}
